## What is this directory for?

Put your private ssh keys here, and then you will be able to refer to the keys by name in order to create SSH tunnels.

## Git Syncing

If you put a `id_rsa` and `id_rsa.pub` key pair here, Retool will use them to authenticate with a remote git repo to sync your Retool apps.

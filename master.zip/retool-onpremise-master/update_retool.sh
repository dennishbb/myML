sudo docker-compose build --pull 
sudo docker-compose pull && sudo docker-compose up -d
sudo docker image prune -a -f
